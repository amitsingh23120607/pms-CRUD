

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


import pms.Reg;
/**
 * Servlet implementation class Logser
 */
@WebServlet("/Logser")
public class Logser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Logser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Query q=s.createQuery("from Reg s where s.username=? and s.password=?");
		q.setString(0, request.getParameter("textuser"));
		q.setString(1, request.getParameter("textpass"));
		List lst = q.list();
 	    if(lst.size()>0)
 	    {
 	    	response.sendRedirect("Viewreg.jsp");
 	    }
 	    else
 	    {
 	    	response.sendRedirect("Login.jsp?q=invalid userid and password");
 	    }
		s.close();

}
}