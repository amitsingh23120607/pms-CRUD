

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pms.Reg;

/**
 * Servlet implementation class Regser
 */
@WebServlet("/Regser")
public class Regser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Regser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		Reg obj = new Reg();
		obj.setUsername(request.getParameter("textuser"));
		obj.setPassword(request.getParameter("textpass"));
		obj.setEmail(request.getParameter("textemail"));
		obj.setPhone(request.getParameter("textphone"));
		s.save(obj);
		tx.commit();
		s.close();
		response.sendRedirect("index.jsp?q=Regisstration successfully");
	}

}
